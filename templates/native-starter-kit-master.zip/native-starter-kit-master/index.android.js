'use strict';

import { AppRegistry } from 'react-native'
import setup from './js/setup'


AppRegistry.registerComponent('NativeStarterKit', setup);
