/* @flow */
/* @flow */
'use strict';

import { StyleSheet } from "react-native";

module.exports = StyleSheet.create({
	sidebar: {
 		flex: 1,
        padding: 10,
        paddingRight: 0,	        
        paddingTop: 30,
 		backgroundColor: '#020000'
    },
});
