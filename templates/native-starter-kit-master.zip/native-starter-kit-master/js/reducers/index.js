/* @flow */

'use strict';

import {combineReducers} from 'redux';

import drawer from './drawer';
import route from './route';

export default combineReducers({
 	drawer,
 	route
})
